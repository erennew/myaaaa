on_pic = "https://telegra.ph/file/5593d624d11d92bceb48e.jpg"
off_pic = "https://telegra.ph/file/0d9e590f62b63b51d4bf9.jpg"
files_cmd_pic = "https://telegra.ph/file/d44f46054250a73053614.jpg"
autodel_cmd_pic = "https://telegra.ph/file/a64533814021b40057ccd.jpg"


START_PIC = "https://telegra.ph/file/ec17880d61180d3312d6a.jpg"

FORCE_PIC = "https://telegra.ph/file/e292b12890b8b4b9dcbd1.jpg"


CUSTOM_CAPTION = "<b>ʙʏ @CulturedTeluguweeb</b>"

#start message
START_MSG = """Hello {mention}

I can store private files in Specified Channel and other users can access it from special link."""


#Force sub message 
FORCE_MSG =  """Hello {mention}

<b>You need to join in my Channel/Group to use me

Kindly Please join Channel...

❗Fᴀᴄɪɴɢ ᴘʀᴏʙʟᴇᴍs, ᴜsᴇ: /help</b>"""

CMD_TXT = """<b>🤖 𝗕𝗔𝗦𝗜𝗖 𝗔𝗗𝗠𝗜𝗡 𝗖𝗢𝗠𝗠𝗔𝗡𝗗𝗦 :

<b>/batch :</b> ᴄʀᴇᴀᴛᴇ ɢʀᴏᴜᴘ ᴍᴇssᴀɢᴇs

<b>/genlink :</b> ᴄʀᴇᴀᴛᴇ ʟɪɴᴋ ғᴏʀ ᴏɴᴇ ᴘᴏsᴛ

<b>/broadcast :</b> ʙʀᴏᴀᴅᴄᴀsᴛ ᴍᴇssᴀɢᴇ

<code>/broadcast silent</code> : sɪʟᴇɴᴛ ʙʀᴏᴀᴅᴄᴀsᴛ ᴍᴇssᴀɢᴇ

<b>/status :</b> ᴠɪᴇᴡ ʙᴏᴛ sᴛᴀᴛɪsᴛɪᴄs"""

BAN_TXT = "<b><blockquote>Sᴏʀʀʏ, ʏᴏᴜ ᴀʀᴇ ʙᴀɴɴᴇᴅ 🚫</blockquote></b>"

HELP_TEXT = """<b>⁉️ Hᴇʟʟᴏ {mention} ~

<blockquote expandable>➪ I ᴀᴍ ᴀ ᴘʀɪᴠᴀᴛᴇ ғɪʟᴇ sʜᴀʀɪɴɢ ʙᴏᴛ, ᴍᴇᴀɴᴛ ᴛᴏ ᴘʀᴏᴠɪᴅᴇ ғɪʟᴇs ᴀɴᴅ ɴᴇᴄᴇssᴀʀʏ sᴛᴜғғ ᴛʜʀᴏᴜɢʜ sᴘᴇᴄɪᴀʟ ʟɪɴᴋ ғᴏʀ sᴘᴇᴄɪғɪᴄ ᴄʜᴀɴɴᴇʟs.

➪ Iɴ ᴏʀᴅᴇʀ ᴛᴏ ɢᴇᴛ ᴛʜᴇ ғɪʟᴇs ʏᴏᴜ ʜᴀᴠᴇ ᴛᴏ ᴊᴏɪɴ ᴛʜᴇ ᴀʟʟ ᴍᴇɴᴛɪᴏɴᴇᴅ ᴄʜᴀɴɴᴇʟ ᴛʜᴀᴛ ɪ ᴘʀᴏᴠɪᴅᴇ ʏᴏᴜ ᴛᴏ ᴊᴏɪɴ. Yᴏᴜ ᴄᴀɴ ɴᴏᴛ ᴀᴄᴄᴇss ᴏʀ ɢᴇᴛ ᴛʜᴇ ғɪʟᴇs ᴜɴʟᴇss ʏᴏᴜ ᴊᴏɪɴᴇᴅ ᴀʟʟ ᴄʜᴀɴɴᴇʟs.

➪ Sᴏ ᴊᴏɪɴ Mᴇɴᴛɪᴏɴᴇᴅ Cʜᴀɴɴᴇʟs ᴛᴏ ɢᴇᴛ Fɪʟᴇs ᴏʀ ɪɴɪᴛɪᴀᴛᴇ ᴍᴇssᴀɢᴇs...

‣ /help -</b> Oᴘᴇɴ ᴛʜɪs ʜᴇʟᴘ ᴍᴇssᴀɢᴇ !</blockquote>
<b><i>◈ Sᴛɪʟʟ ʜᴀᴠᴇ ᴅᴏᴜʙᴛs, ᴄᴏɴᴛᴀᴄᴛ ʙᴇʟᴏᴡ ᴘᴇʀsᴏɴs/ɢʀᴏᴜᴘ ᴀs ᴘᴇʀ ʏᴏᴜʀ ɴᴇᴇᴅ !</i></b>"""

ABOUT_TXT = """<b>🤖 ᴍʏ ɴᴀᴍᴇ: {botname}
<blockquote expandable>◈ ᴀᴅᴠᴀɴᴄᴇ ғᴇᴀᴛᴜʀᴇs: <a href='https://telegra.ph/BOT-FEATURES-11-09-28'>Cʟɪᴄᴋ ʜᴇʀᴇ</a>
◈ ᴏᴡɴᴇʀ: {ownername}
◈ ʟᴀɴɢᴜᴀɢᴇ: <a href='https://docs.python.org/3/'>Pʏᴛʜᴏɴ 3</a>
◈ ʟɪʙʀᴀʀʏ: <a href='https://docs.pyrogram.org/'>Pʏʀᴏɢʀᴀᴍ ᴠ2</a>
◈ ᴅᴀᴛᴀʙᴀsᴇ: <a href='https://www.mongodb.com/docs/'>Mᴏɴɢᴏ ᴅʙ</a>
🧑‍💻 ᴅᴇᴠᴇʟᴏᴘᴇʀ: @rohit_1888</b></blockquote>"""

SETTING_TXT = """<b>⚙️ Cᴏɴғɪɢᴜʀᴀᴛɪᴏɴs</b>
<blockquote expandable>◈ ᴛᴏᴛᴀʟ ғᴏʀᴄᴇ sᴜʙ ᴄʜᴀɴɴᴇʟ:  <b>{total_fsub}</b>
◈ ᴛᴏᴛᴀʟ ᴀᴅᴍɪɴs:  <b>{total_admin}</b>
◈ ᴛᴏᴛᴀʟ ʙᴀɴɴᴇᴅ ᴜsᴇʀs:  <b>{total_ban}</b>
◈ ᴀᴜᴛᴏ ᴅᴇʟᴇᴛᴇ ᴍᴏᴅᴇ:  <b>{autodel_mode}</b>
◈ ᴘʀᴏᴛᴇᴄᴛ ᴄᴏɴᴛᴇɴᴛ:  <b>{protect_content}</b>
◈ ʜɪᴅᴇ ᴄᴀᴘᴛɪᴏɴ:  <b>{hide_caption}</b>
◈ ᴄʜᴀɴɴᴇʟ ʙᴜᴛᴛᴏɴ:  <b>{chnl_butn}</b>
◈ ʀᴇǫᴜᴇsᴛ ғsᴜʙ ᴍᴏᴅᴇ: <b>{reqfsub}</b></blockquote>"""

on_txt, off_txt = "Eɴᴀʙʟᴇᴅ ✅", "Dɪsᴀʙʟᴇᴅ ❌"

FILES_CMD_TXT ="""<b>🤖 𝗙𝗜𝗟𝗘𝗦 𝗥𝗘𝗟𝗔𝗧𝗘𝗗 𝗦𝗘𝗧𝗧𝗜𝗡𝗚𝗦 ⚙️

<blockquote expandable>🔒 ᴘʀᴏᴛᴇᴄᴛ ᴄᴏɴᴛᴇɴᴛ: {protect_content}
🫥 ʜɪᴅᴇ ᴄᴀᴘᴛɪᴏɴ: {hide_caption}
🔘 ᴄʜᴀɴɴᴇʟ ʙᴜᴛᴛᴏɴ: {channel_button}</b>

◈ ʙᴜᴛᴛᴏɴ Nᴀᴍᴇ: {name}
◈ ʙᴜᴛᴛᴏɴ Lɪɴᴋ: {link}</blockquote>

<b>ᴄʟɪᴄᴋ ʙᴇʟᴏᴡ ʙᴜᴛᴛᴏɴs ᴛᴏ ᴄʜᴀɴɢᴇ sᴇᴛᴛɪɴɢs</b>"""

AUTODEL_CMD_TXT = """<b>🤖 𝗔𝗨𝗧𝗢 𝗗𝗘𝗟𝗘𝗧𝗘 𝗦𝗘𝗧𝗧𝗜𝗡𝗚𝗦 ⚙️

<blockquote>🗑️ ᴀᴜᴛᴏ ᴅᴇʟᴇᴛᴇ ᴍᴏᴅᴇ: {autodel_mode}</blockquote>
<blockquote>⏱ ᴅᴇʟᴇᴛᴇ ᴛɪᴍᴇʀ: {timer}</blockquote>

ᴄʟɪᴄᴋ ʙᴇʟᴏᴡ ʙᴜᴛᴛᴏɴs ᴛᴏ ᴄʜᴀɴɢᴇ sᴇᴛᴛɪɴɢs</b>"""

FSUB_CMD_TXT = """<b>🤖 𝗙𝗢𝗥𝗖𝗘 𝗦𝗨𝗕 𝗖𝗢𝗠𝗠𝗔𝗡𝗗𝗦 :</b>

<b>/fsub_chnl</b> : ᴄʜᴇᴄᴋ ᴄᴜʀʀᴇɴᴛ ғᴏʀᴄᴇ-sᴜʙ ᴄʜᴀɴɴᴇʟs (ᴀᴅᴍɪɴs)

<b>/add_fsub</b> : ᴀᴅᴅ ᴏɴᴇ ᴏʀ ᴍᴜʟᴛɪᴘʟᴇ ғᴏʀᴄᴇ sᴜʙ ᴄʜᴀɴɴᴇʟs (ᴏᴡɴᴇʀ)

<b>/del_fsub</b> : ᴅᴇʟᴇᴛᴇ ᴏɴᴇ ᴏʀ ᴍᴜʟᴛɪᴘʟᴇ ғᴏʀᴄᴇ sᴜʙ ᴄʜᴀɴɴᴇʟs (ᴏᴡɴᴇʀ)"""


USER_CMD_TXT = """<b>🤖 𝗨𝗦𝗘𝗥 𝗦𝗘𝗧𝗧𝗜𝗡𝗚 𝗖𝗢𝗠𝗠𝗔𝗡𝗗𝗦 :</b>
    
<b>/admin_list</b> : ᴠɪᴇᴡ ᴛʜᴇ ᴀᴠᴀɪʟᴀʙʟᴇ ᴀᴅᴍɪɴ ʟɪsᴛ (ᴏᴡɴᴇʀ)

<b>/add_admins</b> : ᴀᴅᴅ ᴏɴᴇ ᴏʀ ᴍᴜʟᴛɪᴘʟᴇ ᴜsᴇʀ ɪᴅs ᴀs ᴀᴅᴍɪɴ (ᴏᴡɴᴇʀ)

<b>/del_admins</b> : ᴅᴇʟᴇᴛᴇ ᴏɴᴇ ᴏʀ ᴍᴜʟᴛɪᴘʟᴇ ᴜsᴇʀ ɪᴅs ғʀᴏᴍ ᴀᴅᴍɪɴs (ᴏᴡɴᴇʀ)

<b>/banuser_list</b> : ᴠɪᴇᴡ ᴛʜᴇ ᴀᴠᴀɪʟᴀʙʟᴇ ʙᴀɴɴᴇᴅ ᴜsᴇʀ ʟɪsᴛ (ᴀᴅᴍɪɴs)

<b>/add_banuser</b> : ᴀᴅᴅ ᴏɴᴇ ᴏʀ ᴍᴜʟᴛɪᴘʟᴇ ᴜsᴇʀ ɪᴅs ɪɴ ʙᴀɴɴᴇᴅ ʟɪsᴛ (ᴀᴅᴍɪɴs)

<b>/del_banuser</b> : ᴅᴇʟᴇᴛᴇ ᴏɴᴇ ᴏʀ ᴍᴜʟᴛɪᴘʟᴇ ᴜsᴇʀ ɪᴅs ғʀᴏᴍ ʙᴀɴɴᴇᴅ ʟɪsᴛ (ᴀᴅᴍɪɴs)"""



RFSUB_CMD_TXT = """<b>🤖 𝗥𝗘𝗤𝗨𝗘𝗦𝗧 𝗙𝗦𝗨𝗕 𝗦𝗘𝗧𝗧𝗜𝗡𝗚𝗦 🚦

<blockquote><b>📢 ʀᴇǫᴜᴇsᴛ ғsᴜʙ ᴍᴏᴅᴇ: {req_mode}</b></blockquote>

ᴄʟɪᴄᴋ ʙᴇʟᴏᴡ ʙᴜᴛᴛᴏɴs ᴛᴏ ᴄʜᴀɴɢᴇ sᴇᴛᴛɪɴɢs</b>"""


RFSUB_MS_TXT = """<b>🤖 𝗥𝗘𝗤𝗨𝗘𝗦𝗧 𝗙𝗦𝗨𝗕 𝗟𝗜𝗦𝗧 🚥

<blockquote expandable>{reqfsub_list}</blockquote>
ᴄʟɪᴄᴋ ʙᴇʟᴏᴡ ʙᴜᴛᴛᴏɴs ᴛᴏ ᴄʜᴀɴɢᴇ sᴇᴛᴛɪɴɢs</b>"""

CLEAR_USERS_TXT = """<blockquote expandable><b>What is the use of Clear Users !?</b>

➪ Cʟᴇᴀʀ Usᴇʀs ɪs ᴜsᴇᴅ ᴛᴏ ᴄʟᴇᴀʀ ᴛʜᴇ ᴀʟʟ ᴜsᴇʀ ᴅᴀᴛᴀ ᴏғ ᴀ sᴘᴇᴄɪғɪᴇᴅ Rᴇǫᴜᴇsᴛ ғᴏʀᴄᴇsᴜʙ cʜᴀɴɴᴇʟ ɪᴅ. 

➪ Hᴇʀᴇ oɴʟʏ usᴇʀ ᴅᴀᴛᴀ ɪs ᴅᴇʟᴇᴛᴇᴅ ғʀᴏᴍ sᴘᴇᴄɪғɪᴇᴅ ᴄʜᴀɴɴᴇʟ.</blockquote>

<b><i>Cʜᴏᴏsᴇ ᴛʜᴇ Cʜᴀɴɴᴇʟ ɪᴅ ғᴏʀ ᴅᴇʟᴇᴛɪɴɢ ᴜsᴇʀ ᴅᴀᴛᴀ:</i></b>"""


CLEAR_CHNLS_TXT = """<blockquote expandable><b>What is the use of Clear Channels !?</b>

➪ Cʟᴇᴀʀ Cʜᴀɴɴᴇʟs ᴜsᴇᴅ ᴛᴏ Dᴇʟᴇᴛᴇ ᴀʟʟ ᴜsᴇʀ ᴅᴀᴛᴀ ᴀʟᴏɴɢ ᴡɪᴛʜ Rᴇǫᴜᴇsᴛ ғᴏʀᴄᴇsᴜʙ ᴄʜᴀɴɴᴇʟ ɪᴅ ᴀɴᴅ ʟɪɴᴋ ғʀᴏᴍ ᴅᴀᴛᴀʙᴀsᴇ. 

➪ Hᴇʀᴇ ᴀʟʟ ᴅᴀᴛᴀ ʀᴇᴀʟᴛᴇᴅ ᴛᴏ ʀᴇǫᴜᴇsᴛ ғᴏʀᴄᴇsᴜʙ ᴄʜᴀɴɴᴇʟ ɪᴅ ᴅᴇʟᴇᴛᴇᴅ Pᴇʀᴍᴀɴᴇɴᴛʟʏ...

<b>⚠️ WARNING:</b> Cʟᴇᴀʀ ᴛʜᴇ ᴄʜᴀɴɴᴇʟ ᴅᴀᴛᴀ ᴏɴʟʏ ᴡʜᴇɴ ɪᴛ ɪs ᴄᴏɴғɪʀᴍᴇᴅ ᴛʜᴀᴛ ᴛʜᴇ ᴅᴀᴛᴀ ᴡɪʟʟ ɴᴏ ʟᴏɴɢᴇʀ ʙᴇ ʀᴇǫᴜɪʀᴇᴅ ғᴏʀ ғᴜᴛᴜʀᴇ ᴏᴘᴇʀᴀᴛɪᴏɴs.</blockquote>

<b><i>Cʜᴏᴏsᴇ ᴛʜᴇ Cʜᴀɴɴᴇʟ ɪᴅ ғᴏʀ ᴅᴇʟᴇᴛɪɴɢ:</i></b>"""


CLEAR_LINKS_TXT = """<blockquote expandable><b>What is the use of Clear Links !?</b>

➪ Cʟᴇᴀʀ Sᴛᴏʀᴇᴅ Rᴇǫᴜᴇsᴛ Lɪɴᴋs ᴜsᴇᴅ ᴛᴏ Dᴇʟᴇᴛᴇ Lɪɴᴋs ᴏғ ᴀ sᴘᴇᴄɪғɪᴇᴅ ᴄʜᴀɴɴᴇʟ ɪɴ ᴅᴀᴛᴀʙᴀsᴇ ᴀs ᴡᴇʟʟ ᴀs ʀᴇᴠᴏᴋᴇ ᴛʜᴇ ʟɪɴᴋ ғʀᴏᴍ ᴛʜᴀᴛ Cʜᴀɴɴᴇʟ. 

➪ Eᴠᴇɴ ɪғ ᴄʟᴇᴀʀɪɴɢ ᴄʜᴀɴɴᴇʟ ᴅᴀᴛᴀ ᴛʜᴇ Rᴇǫᴜᴇsᴛ Lɪɴᴋ sᴛᴏʀᴇᴅ ᴏɴ ᴅᴀᴛᴀʙᴀsᴇ ғᴏʀ ғᴜᴛᴜʀᴇ ᴜsɪɴɢ ᴏғ ᴛʜᴀᴛ ᴄʜᴀɴɴᴇʟ, 

➪ Bʏ ᴅᴇʟᴇᴛɪɴɢ ʀᴇǫᴜᴇsᴛ ʟɪɴᴋ ᴏғ sᴘᴇᴄɪғɪᴇᴅ ᴄʜᴀɴɴᴇʟ ᴛʜᴇ ʟɪɴᴋ ᴡɪʟʟ ʙᴇ ʀᴇᴠᴏᴋᴇᴅ ғʀᴏᴍ ᴛʜᴀᴛ ᴄʜᴀɴɴᴇʟ ᴀɴᴅ ɴᴏᴛ ᴜsᴀʙʟᴇ ᴀɴʏ ᴍᴏʀᴇ, 

➪ Sᴏ ᴛʜᴇ ʙᴏᴛ ᴡɪʟʟ ʜᴀᴠᴇ ᴛᴏ ᴄʀᴇᴀᴛᴇ ᴀɢᴀɪɴ ʀᴇǫᴜᴇsᴛ ʟɪɴᴋ ᴏғ ᴛʜᴀᴛ ᴄʜᴀɴɴᴇʟ ɪɴ ғᴜᴛᴜʀᴇ ɪғ ᴛʜᴀᴛ ᴄʜᴀɴɴᴇʟ ᴀɢᴀɪɴ ᴀᴅᴅᴇᴅ ᴀs ʀᴇǫᴜᴇsᴛ ғᴏʀᴄᴇsᴜʙ ᴄʜᴀɴɴᴇʟ.

<b>⚠️ NOTE:</b> 
‣ Tᴏ ᴘᴇʀғᴏʀᴍ ᴛʜɪs ᴀᴄᴛɪᴏɴ ᴛʜᴇ ʙᴏᴛ sʜᴏᴜʟᴅ ʜᴀᴠᴇ ᴀᴅᴍɪɴ ᴀʟᴏɴɢ ᴡɪᴛʜ ᴘʀᴏᴘᴇʀ ᴘᴇʀᴍɪssɪᴏɴ ᴏɴ ᴛʜᴀᴛ ᴄʜᴀɴɴᴇʟ. 

‣ ɪғ ᴛʜᴇ ʙᴏᴛ ɴᴏᴛ ɪɴ ᴛʜᴀᴛ ᴄʜᴀɴɴᴇʟ ᴏʀ ᴅᴏɴ'ᴛ ʜᴀᴠᴇ ᴀᴅᴍɪɴ ᴘᴇʀᴍɪssɪᴏɴ ᴛʜᴇɴ ᴛʜɪs ᴏᴘᴇʀᴀᴛɪᴏɴ ᴄᴀɴ'ᴛ ʙᴇ ᴘᴇʀғᴏʀᴍᴇᴅ.</blockquote>

<b><i>Cʜᴏᴏsᴇ ᴛʜᴇ Cʜᴀɴɴᴇʟ ɪᴅ ғᴏʀ ᴅᴇʟᴇᴛɪɴɢ Rᴇǫᴜᴇsᴛ Lɪɴᴋ:</i></b>"""